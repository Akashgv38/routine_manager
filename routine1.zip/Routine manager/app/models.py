from werkzeug.security import generate_password_hash, check_password_hash
from flask import current_app
from flask_login import UserMixin
from bson.objectid import ObjectId  # Import ObjectId

class User(UserMixin):
    def __init__(self, id, name, email, password_hash):
        self.id = id
        self.name = name
        self.email = email
        self.password_hash = password_hash

def get_tasks(user_id):
    tasks = current_app.db.tasks.find({"user_id": ObjectId(user_id)})
    return list(tasks)

def get_task(task_id):
    return current_app.db.tasks.find_one({"_id": ObjectId(task_id)})

def add_task(user_id, title, description):
    task = {"user_id": ObjectId(user_id), "title": title, "description": description, "status": "Pending"}
    current_app.db.tasks.insert_one(task)

def update_task(task_id, title, description):
    current_app.db.tasks.update_one({"_id": ObjectId(task_id)}, {"$set": {"title": title, "description": description}})

def delete_task(task_id):
    current_app.db.tasks.delete_one({"_id": ObjectId(task_id)})

def create_user(name, email, password):
    password_hash = generate_password_hash(password)
    user = {"name": name, "email": email, "password": password_hash}
    current_app.db.users.insert_one(user)

def authenticate_user(email, password):
    user_data = current_app.db.users.find_one({"email": email})
    if user_data and check_password_hash(user_data["password"], password):
        return User(str(user_data["_id"]), user_data["name"], user_data["email"], user_data["password"])
    return None

def load_user(user_id):
    user_data = current_app.db.users.find_one({"_id": ObjectId(user_id)})
    if user_data:
        return User(str(user_data["_id"]), user_data["name"], user_data["email"], user_data["password"])
    return None
