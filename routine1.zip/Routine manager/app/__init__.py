from flask import Flask
from flask_login import LoginManager
from config import Config
from pymongo import MongoClient

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    client = MongoClient(app.config['MONGO_URI'])
    app.db = client[app.config['MONGO_DBNAME']]

    login_manager = LoginManager()
    login_manager.init_app(app)
    login_manager.login_view = 'main.login'

    from app.models import load_user
    login_manager.user_loader(load_user)

    from app.routes import main as main_blueprint
    app.register_blueprint(main_blueprint)

    return app
