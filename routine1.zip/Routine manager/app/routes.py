from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_user, login_required, logout_user, current_user
from app.models import get_tasks, get_task, add_task, update_task, delete_task, create_user, authenticate_user

main = Blueprint('main', __name__)

@main.route('/')
def index():
    return render_template('index.html')

@main.route('/features')
def features():
    return render_template('features.html')

@main.route('/pricing')
def pricing():
    return render_template('pricing.html')

@main.route('/about')
def about():
    return render_template('about.html')

@main.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        message = request.form['message']
        # Process the data, send email, etc.
        flash('Message sent successfully!')
        return redirect(url_for('main.contact'))
    return render_template('contact.html')

@main.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = authenticate_user(email, password)
        if user:
            login_user(user)
            flash('Logged in successfully!')
            return redirect(url_for('main.dashboard'))
        else:
            flash('Login failed. Check your email and password.')
    return render_template('login.html')

@main.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        create_user(name, email, password)
        flash('Signup successful! Please log in.')
        return redirect(url_for('main.login'))
    return render_template('signup.html')

@main.route('/dashboard')
@login_required
def dashboard():
    tasks = get_tasks(current_user.id)
    return render_template('dashboard.html', tasks=tasks)

@main.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.')
    return redirect(url_for('main.index'))

@main.route('/add_task', methods=['GET', 'POST'])
@login_required
def add_task():
    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        add_task(current_user.id, title, description)
        flash('Task added successfully!')
        return redirect(url_for('main.dashboard'))
    return render_template('add_task.html')

@main.route('/edit_task/<task_id>', methods=['GET', 'POST'])
@login_required
def edit_task(task_id):
    task = get_task(task_id)
    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        update_task(task_id, title, description)
        flash('Task updated successfully!')
        return redirect(url_for('main.dashboard'))
    return render_template('edit_task.html', task=task)

@main.route('/delete_task/<task_id>', methods=['POST'])
@login_required
def delete_task(task_id):
    delete_task(task_id)
    flash('Task deleted successfully!')
    return redirect(url_for('main.dashboard'))
