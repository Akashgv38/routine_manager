import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY')
    MONGO_URI = 'mongodb+srv://Akashgv123:Akashgv@routinemanager.p8b4udu.mongodb.net/?retryWrites=true&w=majority&appName=routinemanager'
    MONGO_DBNAME = os.environ.get('MONGO_DBNAME') or 'routine_manager'
